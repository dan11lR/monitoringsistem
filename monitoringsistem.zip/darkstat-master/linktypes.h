const char* get_linktype_name(int linktype);
