# darkstat

https://unix4lyfe.org/darkstat/

darkstat is a network statistics gatherer.

It sniffs packets on a specified interface, accumulates statistics, and
serves them up over HTTP.

See the "AUTHORS" file for credits, and who to e-mail when things break.
See the "LICENSE" file for an explanation of the source code licensing.
See the "INSTALL" file for installation instructions.
See the "darkstat.8" manual page for usage instructions.

If your system doesn't have enough copies of the full text of the GNU
General Public License already, we have provided another one in the
"COPYING.GPL" file.
